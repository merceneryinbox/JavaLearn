package clientside;

import entries.EntryDic;

import java.io.*;
import java.net.Socket;
import java.util.concurrent.Callable;


/**
 * Created by mercenery on 06.06.2017.
 */


public class DoItWithEntry implements Callable<EntryDic>{
	
	EntryDic entryDic;
	static Socket             socket;
	static ObjectInputStream  objectInputStream;
	static ObjectOutputStream objectOutputStream;
	
	/**
	 * Конструктор класса при инизиализации инициализирует общую переменную  <code>entryDic</code> типа
	 * <code>EntryDic</code>.
	 *
	 * @param entryDic
	 */
	
	
	public DoItWithEntry(EntryDic entryDic) throws InterruptedException{
		this.entryDic = entryDic;
		System.out.println(
			"DoIt : Constructor of DoIt starts: EntryDic iniated in DoIt constructor, socket creation starts");
		System.out.println(
			"DoIt :  - entryDic from Controller to DoIt granted : " + this.entryDic.flag + " " + this.entryDic.word
			+ " " + this.entryDic.definition);
		Thread.sleep(5000);
		try{
			socket = new Socket("localhost", 23345);
			objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
			objectInputStream = new ObjectInputStream(socket.getInputStream());
		} catch(IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("DoIt : Socket creation succes in DoIt class, io channels creation starts");
		
		System.out.println("DoIt : Channels in client's socket in constructor of DoIt created");
		
		System.out.println("DoIt : Constructor of DoIt ended");
	}
	
	/**
	 * Computes a result, or throws an exception if unable to do so.
	 * <p>
	 * Перегруженный метод <code>call</code> объявляет и инициализирует сокет <code>socket</code> для обработки
	 * поступившего на входе в конструктор <code>entryDic</code>. Объявляет каналы обмена сообщения
	 *
	 * @return computed result
	 * @throws Exception if unable to compute a result
	 */
	@Override
	public EntryDic call() throws Exception{
		System.out.println("DoIt : Call method in DoIt starts ");
		try{
			
			System.out.println(
				"DoIt : EntryDic try to write from DoIt to CSD in channel - " + entryDic.flag + "" + " " + entryDic.word
				+ " " + entryDic.definition);
// передаём в канал для сервера объект полученный из контроллера
			objectOutputStream.writeObject(entryDic);
			objectOutputStream.flush();
			System.out.println("DoIt : entryDic wrote in socket channel to CSDialog, while loop waits for "
			                   + "reply from CSDialog starts");

// дожидаемся ответа
			
			System.out.println("DoIt : reply from CSDialog granted");
// возвращаем полученный из сервера объект содержащий внутри себя ответ
			EntryDic replyEntryFromCSDIalog = (EntryDic)objectInputStream.readObject();
			System.out.println(
				"DoIt : EntryDic = " + replyEntryFromCSDIalog.flag + " ; " + replyEntryFromCSDIalog.word + " "
				+ replyEntryFromCSDIalog.definition);
			return replyEntryFromCSDIalog;
		} catch(IOException e) {
			e.printStackTrace();

// в случает ошибки соединения или чтения/записи объекта в канал возвращаем контроллекру ошибку
			return new EntryDic(2, "error ", "error ");
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
// в случает ошибки соединения или чтения/записи объекта в канал возвращаем контроллекру ошибку
			return new EntryDic(2, "error ", "error ");
		}
	}
}
